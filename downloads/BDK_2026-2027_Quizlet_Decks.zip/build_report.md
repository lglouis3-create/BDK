# BDK Quizlet deck build report

Source: 2026-2027 Basic Drug Knowledge List ("BDK List Revised May 2026"), pages 2-27.

## Card counts per file

| Page | File | Cards |
| --- | --- | ---: |
| 2 | BDK_p2_DEENT1_Cards.txt | 53 |
| 2 | BDK_p2_DEENT1_SelectALL.txt | 5 |
| 2 | BDK_p2_DEENT1_EssentialKnowledge.txt | 15 |
| 3 | BDK_p3_DEENT2_Cards.txt | 64 |
| 3 | BDK_p3_DEENT2_SelectALL.txt | 6 |
| 3 | BDK_p3_DEENT2_EssentialKnowledge.txt | 15 |
| 4 | BDK_p4_Renal_Cards.txt | 57 |
| 4 | BDK_p4_Renal_SelectALL.txt | 6 |
| 4 | BDK_p4_Renal_EssentialKnowledge.txt | 23 |
| 5 | BDK_p5_CV1_Cards.txt | 82 |
| 5 | BDK_p5_CV1_SelectALL.txt | 10 |
| 5 | BDK_p5_CV1_EssentialKnowledge.txt | 11 |
| 6 | BDK_p6_CV2_Cards.txt | 60 |
| 6 | BDK_p6_CV2_SelectALL.txt | 9 |
| 6 | BDK_p6_CV2_EssentialKnowledge.txt | 23 |
| 7 | BDK_p7_CV3_Cards.txt | 43 |
| 7 | BDK_p7_CV3_SelectALL.txt | 7 |
| 7 | BDK_p7_CV3_EssentialKnowledge.txt | 22 |
| 8 | BDK_p8_CV4_Cards.txt | 45 |
| 8 | BDK_p8_CV4_SelectALL.txt | 8 |
| 8 | BDK_p8_CV4_EssentialKnowledge.txt | 11 |
| 9 | BDK_p9_Pulmonary_Cards.txt | 40 |
| 9 | BDK_p9_Pulmonary_SelectALL.txt | 4 |
| 9 | BDK_p9_Pulmonary_EssentialKnowledge.txt | 11 |
| 10 | BDK_p10_ID1_Cards.txt | 40 |
| 10 | BDK_p10_ID1_SelectALL.txt | 14 |
| 10 | BDK_p10_ID1_EssentialKnowledge.txt | 2 |
| 10 | BDK_p10_ID1_Organisms.txt | 19 |
| 11 | BDK_p11_ID2_Cards.txt | 36 |
| 11 | BDK_p11_ID2_SelectALL.txt | 11 |
| 11 | BDK_p11_ID2_EssentialKnowledge.txt | 9 |
| 11 | BDK_p11_ID2_Organisms.txt | 15 |
| 12 | BDK_p12_ID3_Cards.txt | 37 |
| 12 | BDK_p12_ID3_SelectALL.txt | 6 |
| 12 | BDK_p12_ID3_EssentialKnowledge.txt | 10 |
| 12 | BDK_p12_ID3_Organisms.txt | 10 |
| 13 | BDK_p13_ID4_Cards.txt | 56 |
| 13 | BDK_p13_ID4_SelectALL.txt | 8 |
| 13 | BDK_p13_ID4_EssentialKnowledge.txt | 22 |
| 13 | BDK_p13_ID4_Organisms.txt | 0 |
| 14 | BDK_p14_MSK_Cards.txt | 78 |
| 14 | BDK_p14_MSK_SelectALL.txt | 11 |
| 14 | BDK_p14_MSK_EssentialKnowledge.txt | 21 |
| 15 | BDK_p15_Endo1_Cards.txt | 66 |
| 15 | BDK_p15_Endo1_SelectALL.txt | 10 |
| 15 | BDK_p15_Endo1_EssentialKnowledge.txt | 15 |
| 16 | BDK_p16_Endo2_Cards.txt | 36 |
| 16 | BDK_p16_Endo2_SelectALL.txt | 6 |
| 16 | BDK_p16_Endo2_EssentialKnowledge.txt | 9 |
| 17 | BDK_p17_Endo3_Cards.txt | 33 |
| 17 | BDK_p17_Endo3_SelectALL.txt | 5 |
| 17 | BDK_p17_Endo3_EssentialKnowledge.txt | 14 |
| 18 | BDK_p18_CNS1_Cards.txt | 60 |
| 18 | BDK_p18_CNS1_SelectALL.txt | 7 |
| 18 | BDK_p18_CNS1_EssentialKnowledge.txt | 22 |
| 19 | BDK_p19_CNS2_Cards.txt | 41 |
| 19 | BDK_p19_CNS2_SelectALL.txt | 8 |
| 19 | BDK_p19_CNS2_EssentialKnowledge.txt | 10 |
| 20 | BDK_p20_CNS3_Cards.txt | 40 |
| 20 | BDK_p20_CNS3_SelectALL.txt | 6 |
| 20 | BDK_p20_CNS3_EssentialKnowledge.txt | 18 |
| 21 | BDK_p21_CNS4_Cards.txt | 33 |
| 21 | BDK_p21_CNS4_SelectALL.txt | 5 |
| 21 | BDK_p21_CNS4_EssentialKnowledge.txt | 10 |
| 22 | BDK_p22_CNS5_Cards.txt | 41 |
| 22 | BDK_p22_CNS5_SelectALL.txt | 6 |
| 22 | BDK_p22_CNS5_EssentialKnowledge.txt | 14 |
| 23 | BDK_p23_GI1_Cards.txt | 48 |
| 23 | BDK_p23_GI1_SelectALL.txt | 8 |
| 23 | BDK_p23_GI1_EssentialKnowledge.txt | 12 |
| 24 | BDK_p24_GI2_Cards.txt | 53 |
| 24 | BDK_p24_GI2_SelectALL.txt | 10 |
| 24 | BDK_p24_GI2_EssentialKnowledge.txt | 13 |
| 25 | BDK_p25_PainHemeOnc1_Cards.txt | 35 |
| 25 | BDK_p25_PainHemeOnc1_SelectALL.txt | 3 |
| 25 | BDK_p25_PainHemeOnc1_EssentialKnowledge.txt | 14 |
| 26 | BDK_p26_PainHemeOnc2_Cards.txt | 35 |
| 26 | BDK_p26_PainHemeOnc2_SelectALL.txt | 6 |
| 26 | BDK_p26_PainHemeOnc2_EssentialKnowledge.txt | 13 |
| 27 | BDK_p27_PainHemeOnc3_Cards.txt | 24 |
| 27 | BDK_p27_PainHemeOnc3_SelectALL.txt | 2 |
| 27 | BDK_p27_PainHemeOnc3_EssentialKnowledge.txt | 14 |

Total cards: 1840 in 82 files.

## Audit (run in code)

- p2 DEENT1 (12 drugs): passed
- p3 DEENT2 (13 drugs): passed
- p4 Renal (14 drugs): passed
- p5 CV1 (21 drugs): 5 problem(s)
  - not in EssentialKnowledge: amlodipine and benazepril (Lotrel)
  - not in EssentialKnowledge: lisinopril and hydrochlorothiazide (Zestoretic)
  - not in EssentialKnowledge: losartan and hydrochlorothiazide (Hyzaar)
  - not in EssentialKnowledge: olmesartan and hydrochlorothiazide (Benicar-HCT)
  - not in EssentialKnowledge: valsartan and hydrochlorothiazide (Diovan-HCT)
- p6 CV2 (15 drugs): passed
- p7 CV3 (11 drugs): passed
- p8 CV4 (11 drugs): passed
- p9 Pulmonary (10 drugs): passed
- p10 ID1 (11 drugs): passed
- p11 ID2 (9 drugs): passed
- p12 ID3 (9 drugs): passed
- p13 ID4 (14 drugs): passed
- p14 MSK (19 drugs): passed
- p15 Endo1 (16 drugs): passed
- p16 Endo2 (9 drugs): passed
- p17 Endo3 (8 drugs): passed
- p18 CNS1 (15 drugs): passed
- p19 CNS2 (10 drugs): passed
- p20 CNS3 (10 drugs): passed
- p21 CNS4 (8 drugs): passed
- p22 CNS5 (10 drugs): passed
- p23 GI1 (11 drugs): passed
- p24 GI2 (12 drugs): passed
- p25 PainHemeOnc1 (8 drugs): passed
- p26 PainHemeOnc2 (8 drugs): passed
- p27 PainHemeOnc3 (6 drugs): passed

## Abbreviation expansions

| Abbreviation | Written as | Source | Pages |
| --- | --- | --- | --- |
| ACE | angiotensin-converting enzyme (ACE) | **FLAGGED: outside legend** | 5 |
| ARB | angiotensin II receptor blocker (ARB) | **FLAGGED: outside legend** | 5 |
| CCB | calcium channel blocker (CCB) | **FLAGGED: outside legend** | 5 |
| CI | contraindicated (CI) | **FLAGGED: outside legend** | 2, 4, 6, 7, 14, 15, 16, 17, 18, 19, 20, 22, 23, 24 |
| CNS | central nervous system (CNS) | **FLAGGED: outside legend** | 3, 11, 17, 19, 25, 26, 27 |
| COVID-19 | coronavirus disease 2019 (COVID-19) | **FLAGGED: outside legend** | 13 |
| COX-2 | cyclooxygenase-2 (COX-2) | **FLAGGED: outside legend** | 14 |
| CS-II | controlled substance schedule II (CS-II) | **FLAGGED: outside legend** | 19, 25, 26 |
| CS-III | controlled substance schedule III (CS-III) | **FLAGGED: outside legend** | 17, 26 |
| CS-IV | controlled substance schedule IV (CS-IV) | **FLAGGED: outside legend** | 17, 22, 25 |
| CS-V | controlled substance schedule V (CS-V) | **FLAGGED: outside legend** | 3, 21 |
| eGFR | estimated glomerular filtration rate (eGFR) | **FLAGGED: outside legend** | 15 |
| GI | gastrointestinal (GI) | **FLAGGED: outside legend** | 20, 24 |
| GLP-1 | glucagon-like peptide-1 (GLP-1) | **FLAGGED: outside legend** | 15 |
| HMG-CoA | 3-hydroxy-3-methylglutaryl coenzyme A (HMG-CoA) | **FLAGGED: outside legend** | 8 |
| INR | international normalized ratio (INR) | **FLAGGED: outside legend** | 7 |
| INSTIs | integrase strand transfer inhibitors (INSTIs) | **FLAGGED: outside legend** | 13 |
| NSAID | nonsteroidal anti-inflammatory drug (NSAID) | **FLAGGED: outside legend** | 7, 14 |
| NSAIDs | nonsteroidal anti-inflammatory drugs (NSAIDs) | **FLAGGED: outside legend** | 27 |
| NYHA | New York Heart Association (NYHA) | **FLAGGED: outside legend** | 15 |
| OTC | over-the-counter (OTC) | **FLAGGED: outside legend** | 2, 3, 4, 7, 8, 12, 13, 14, 15, 17, 22, 23, 24, 25, 26 |
| PDE-5 | phosphodiesterase-5 (PDE-5) | **FLAGGED: outside legend** | 7 |
| QTc | corrected QT interval (QTc) | **FLAGGED: outside legend** | 3, 11, 13, 20, 24, 25 |
| Rx | prescription (Rx) | **FLAGGED: outside legend** | 8 |
| ACS | acute coronary syndrome (ACS) | page footer | 7 |
| ADHD | attention-deficit/hyperactivity disorder (ADHD) | page footer | 6, 18, 19 |
| AF | atrial fibrillation (AF) | page footer | 5, 6, 7, 8 |
| BPH | benign prostatic hyperplasia (BPH) | page footer | 4, 17 |
| CAD | coronary artery disease (CAD) | page footer | 5, 6, 7, 8, 27 |
| CAP | community acquired pneumonia (CAP) | page footer | 10 |
| CAP | community-acquired pneumonia (CAP) | page footer | 11 |
| CDI | Clostridioides difficile infection (CDI) | page footer | 11, 12 |
| CINV | chemotherapy induced nausea and vomiting (CINV) | page footer | 23 |
| CKD | chronic kidney disease (CKD) | page footer | 15 |
| COPD | chronic obstructive pulmonary disease (COPD) | page footer | 9, 23 |
| CRBSI | catheter-related bloodstream infection (CRBSI) | page footer | 10 |
| CRBSI | catheter-related blood stream infection (CRBSI) | page footer | 12 |
| DFI | diabetic foot infection (DFI) | page footer | 10, 11 |
| DILE | drug induced lupus erythematosus (DILE) | page footer | 11 |
| DKA | diabetic ketoacidosis (DKA) | page footer | 15 |
| DM | diabetes mellitus (DM) | page footer | 15 |
| DVT/PE | deep vein thrombosis/pulmonary embolism (DVT/PE) | page footer | 27 |
| ED | erectile dysfunction (ED) | page footer | 17 |
| EPS | extrapyramidal symptoms (EPS) | page footer | 20, 24 |
| ESBL | extended spectrum beta lactamase (ESBL) | page footer | 11 |
| GERD | gastroesophageal reflux disease (GERD) | page footer | 24 |
| GI | gastrointestinal (GI) | page footer | 27 |
| HAP | hospital-acquired pneumonia (HAP) | page footer | 10, 11, 12 |
| HF | heart failure (HF) | page footer | 5, 6, 15 |
| HIT | heparin-induced thrombocytopenia (HIT) | page footer | 7 |
| HIV | human immunodeficiency virus (HIV) | page footer | 13 |
| HTN | hypertension (HTN) | page footer | 4, 5, 6, 7, 19 |
| IAI | intra-abdominal infection (IAI) | page footer | 10, 11 |
| IBS | irritable bowel syndrome (IBS) | page footer | 23 |
| IBS-C | irritable bowel syndrome with constipation (IBS-C) | page footer | 23 |
| IOP | intraocular pressure (IOP) | page footer | 2 |
| MAOI | monoamine oxidase inhibitor (MAOI) | page footer | 2, 14, 17, 18, 19, 22 |
| MDD | major depressive disorder (MDD) | page footer | 18, 20 |
| MI | myocardial infarction (MI) | page footer | 14 |
| MRSA | methicillin-resistant Staphylococcus aureus (MRSA) | page footer | 11, 12 |
| MSSA | methicillin-susceptible Staphylococcus aureus (MSSA) | page footer | 10, 12 |
| OA | osteoarthritis (OA) | page footer | 14 |
| PAD | peripheral arterial disease (PAD) | page footer | 7 |
| PAH | pulmonary arterial hypertension (PAH) | page footer | 17 |
| PCOS | polycystic ovarian syndrome (PCOS) | page footer | 15 |
| PE | pulmonary embolism (PE) | page footer | 7 |
| PEP | postexposure prophylaxis (PEP) | page footer | 13 |
| PreP | preexposure prophylaxis (PreP) | page footer | 13 |
| PUD | peptic ulcer disease (PUD) | page footer | 24 |
| RA | rheumatoid arthritis (RA) | page footer | 14 |
| RLS | restless legs syndrome (RLS) | page footer | 19 |
| SBP | spontaneous bacterial peritonitis (SBP) | page footer | 4 |
| SJS | Stevens-Johnson syndrome (SJS) | page footer | 12, 21 |
| SLE | systemic lupus erythematosus (SLE) | page footer | 14 |
| SSTI | skin and soft tissue infection (SSTI) | page footer | 10, 11, 12 |
| STEMI | ST segment elevation myocardial infarction (STEMI) | page footer | 7 |
| SUP | stress ulcer prophylaxis (SUP) | page footer | 24 |
| TEN | toxic epidermal necrolysis (TEN) | page footer | 12, 21 |
| TIA | transient ischemic attack (TIA) | page footer | 20 |
| UTI | urinary tract infection (UTI) | page footer | 15 |
| VAP | ventilator associated pneumonia (VAP) | page footer | 10, 11 |
| VTE | venous thromboembolism (VTE) | page footer | 7, 16 |

Kept as written, not expanded: routes (PO, IV, IM, SQ, SC, SL, PR, INH, IT, IP), enzyme names (CYP3A, CYP3A4, 2B6, 2C19, 2D6), QT, mL.

## Flags for Louis to decide

### indication items split at a line break

- p2: brimonidine (ophthalmic): Elevated IOP | Ocular redness
- p12: neomycin + polymyxin B + bacitracin (topical, ophthalmic): Topical infection prevention | Ocular infections

### combination product (category and indication read "See individual drug components")

- p5: amlodipine and benazepril (Lotrel): cards keep that wording; the notes cell is part of the same merged cell, so no Essential Knowledge card
- p5: lisinopril and hydrochlorothiazide (Zestoretic): cards keep that wording; the notes cell is part of the same merged cell, so no Essential Knowledge card
- p5: losartan and hydrochlorothiazide (Hyzaar): cards keep that wording; the notes cell is part of the same merged cell, so no Essential Knowledge card
- p5: olmesartan and hydrochlorothiazide (Benicar-HCT): cards keep that wording; the notes cell is part of the same merged cell, so no Essential Knowledge card
- p5: valsartan and hydrochlorothiazide (Diovan-HCT): cards keep that wording; the notes cell is part of the same merged cell, so no Essential Knowledge card

### Select ALL group on a placeholder entry

- p5: "pharmacologic category: See individual drug components" groups the 5 combination products (made because they share the exact entry)
- p5: "common indication: See individual drug components." groups the 5 combination products (made because they share the exact entry)

### two separate label headings combined into one card

- p7: warfarin (PO): two "Other Notes" headings in one cell

### classification cell merged across drugs (one combined card)

- p8: OTC: various omega-3 formulations Rx: Lovaza & Vascepa: omega-3 ethyl esters (Lovaza) and icosapent ethyl (Vascepa)
- p19: CS-II: dexmethylphenidate (Focalin, Focalin XR), dextroamphetamine and amphetamine (Adderall, Adderall XR), lisdexamfetamine (Vyvanse), and methylphenidate (Concerta, Ritalin, Daytrana)
- p22: CS-IV: alprazolam (Xanax), clonazepam (Klonopin), diazepam (Valium), lorazepam (Ativan), and midazolam (Versed)
- p25: CS-II: fentanyl (Duragesic, Sublimaze), hydromorphone (Dilaudid), morphine (extended release) (MS Contin, Kadian), morphine (immediate release) (Duramorph, Infumorph), oxycodone (OxyContin, Roxicodone), and methadone (Dolophine)
- p26: CS-II: hydrocodone and acetaminophen (Lortab, Vicodin, Norco) and oxycodone and acetaminophen (Percocet, Endocet)

### brand route suffix dropped in label

- p12: tobramycin (IV, inhaled): "Tobi (inhaled)" -> "Tobi"
- p27: pembrolizumab (IV), pembrolizumab/berahyaluronidase alfa-pmph (SC): "Keytruda(IV)" -> "Keytruda"
- p27: pembrolizumab (IV), pembrolizumab/berahyaluronidase alfa-pmph (SC): "Keytruda Qlex (SC)" -> "Keytruda Qlex"

### organism entry naming two organisms

- p12: clindamycin (Cleocin): "MRSA/MSSA" kept as one item, so it does not join the separate MRSA or MSSA Select ALL groups

### qualified note inside a shared cell

- p14: "US Boxed Warning (only for ketorolac)" assigned to ketorolac (Toradol) only
- p22: "Other Notes (lorazepam IV)" assigned to lorazepam (Ativan) only
- p25: "US Boxed Warning (only for fentanyl)" assigned to fentanyl (Duragesic, Sublimaze) only
- p25: "US Boxed Warning (only for hydromorphone)" assigned to hydromorphone (Dilaudid) only
- p25: "US Boxed Warning (only for morphine, extended release)" assigned to morphine (extended release) (MS Contin, Kadian) only
- p25: "US Boxed Warning (only for oxycodone)" assigned to oxycodone (OxyContin, Roxicodone) only

### "See above" kept as written

- p25: What are the US Boxed Warnings (all opioid analgesics) of methadone (Dolophine)? -> See above
- p26: What are the US Boxed Warnings (all opioid analgesics) of hydrocodone and acetaminophen (Lortab, Vicodin, Norco) and oxycodone and acetaminophen (Percocet, Endocet)? -> See above
- p26: What are the US Boxed Warnings (all opioid analgesics) of codeine and acetaminophen (Tylenol with Codeine #3, Tylenol with Codeine #4)? -> See above

### indication split by hand

- p27: cisplatin (IV, IT, IP): "Advanced bladder, ovarian, and testicular cancer; various cancers" -> (#1) Advanced bladder, ovarian, and testicular cancer; (#2) Various cancers (comma split would cut "Advanced bladder, ovarian, and testicular cancer" into 3)

### route abbreviation inside a note kept as written

- p27: methotrexate (Trexall): "IT" (page footer: intrathecal) left unexpanded because routes stay as written

### kept as written

- p2: cyclosporin
- p4: Calcium acetate
- p10: Enterobacteriacae
- p12: streptococcus species
- p13: PreP
- p18: insomnia. diaphoresis
- p19: PO: Aricept,
- p23: Lactulose
- p27: Keytruda(IV)

## Differences from the 2025-2026 list

### p4 RENAL

- mirabegron (PO) — brand: "Mybetriq" → "Myrbetriq"
- Calcium acetate (PO) — essential: "Key Side Effects: hypercalcemia; nausea, vomiting, constipation Other notes: Each dose of 667mg contains 169mg of elemental calcium" → "Key Side Effects: hypercalcemia, nausea, vomiting, constipation Other notes: Each dose of 667mg contains 169mg of elemental calcium"

### p6 CARDIOVASCULAR 2

- labetalol (PO, IV) — indication: "PO: HTN, IV: hypertensive crisis" → "PO: HTN IV: hypertensive crisis"
- hydralazine (PO, IV) — brand: "---" → "Apresoline"

### p7 CARDIOVASCULAR 3

- clopidogrel (PO) — indication: "CAD, stroke" → "ACS, CAD, stroke"

### p8 CARDIOVASCULAR 4

- omega-3 ethyl esters (PO) — classification: "OTC: available Rx: Lovaza & Vascepa" → "OTC: various omega-3 formulations Rx: Lovaza & Vascepa"
- icosapent ethyl (PO) — classification: "OTC: available Rx: Lovaza & Vascepa" → "OTC: various omega-3 formulations Rx: Lovaza & Vascepa"

### p9 PULMONARY

- added: fluticasone (INH)
- removed: fluticasone propionate (INH)
- budesonide and formoterol (INH) — essential: "Key Side Effects: oral candidiasis, hoarseness (dysphonia), sore throat, nervousness, tremor, tachycardia, palpitations, hyperglycemia, decreased potassium Other Notes: rinse mouth with water and spit out to prevent Candida infection" → "Key Side Effects: oral candidiasis, hoarseness (dysphonia), sore throat, nervousness, tremor, tachycardia, palpitations, hyperglycemia, decreased potassium Other Notes: rinse mouth with water and spit out to prevent oral candidiasis (thrush)"
- mometasone and formoterol (INH) — essential: "Key Side Effects: oral candidiasis, hoarseness (dysphonia), sore throat, nervousness, tremor, tachycardia, palpitations, hyperglycemia, decreased potassium Other Notes: rinse mouth with water and spit out to prevent Candida infection" → "Key Side Effects: oral candidiasis, hoarseness (dysphonia), sore throat, nervousness, tremor, tachycardia, palpitations, hyperglycemia, decreased potassium Other Notes: rinse mouth with water and spit out to prevent oral candidiasis (thrush)"
- budesonide (INH) — essential: "Key Side Effects: oral candidiasis, hoarseness (dysphonia), sore throat Other Notes: rinse mouth with water and spit out to prevent Candida infection" → "Key Side Effects: oral candidiasis, hoarseness (dysphonia), sore throat Other Notes: rinse mouth with water and spit out to prevent oral candidiasis (thrush)"
- albuterol (INH) — brand: "Proventil, Ventolin, ProAir" → "Ventolin, ProAir RespiClick"
- fluticasone and salmeterol (INH) — essential: "Key Side Effects: oral candidiasis, hoarseness (dysphonia), sore throat, nervousness, tremor, tachycardia, palpitations, hyperglycemia, decreased potassium Other Notes: rinse mouth with water and spit out to prevent Candida infection" → "Key Side Effects: oral candidiasis, hoarseness (dysphonia), sore throat, nervousness, tremor, tachycardia, palpitations, hyperglycemia, decreased potassium Other Notes: rinse mouth with water and spit out to prevent oral candidiasis (thrush)"

### p10 INFECTIOUS DISEASES 1

- piperacillin and tazobactam (IV) — indication: "HAP. VAP, DFI, IAI Activity against: Pseudomonas aeruginosa, anaerobes" → "HAP, VAP, DFI, IAI Activity against: Pseudomonas aeruginosa, anaerobes"

### p12 INFECTIOUS DISEASES 3

- clindamycin (PO, IV) — indication: "SSTI, pharyngitis Activity against: MRSA" → "SSTI, pharyngitis Activity against: MRSA/MSSA, streptococcus species, anaerobes"

### p13 INFECTIOUS DISEASES 4

- remdesivir (IV) — essential: "Key Side Effects: hyperglycemia, renal impairment" → "Key Side Effects: hyperglycemia, renal impairment, bradycardia, increased liver enzymes, hypersensitivity"

### p15 ENDOCRINE 1

- metformin (PO) — brand: "Fortamet, Glumetza" → "Fortamet, Glumetza, Riomet"
- metformin (PO) — essential: "Key Side Effects: diarrhea, nausea, vomiting, Vitamin B12 deficiency Other Notes: CI with eGFR <30 US Boxed Warnings: lactic acidosis" → "Key Side Effects: diarrhea, nausea, vomiting, Vitamin B12 deficiency Other Notes: CI with eGFR <30; US Boxed Warnings: lactic acidosis"
- liraglutide (SQ) — essential: "Key Side Effects: nausea, vomiting, diarrhea, constipation, pancreatitis US Boxed Warning: may increase risk of thyroid c-cell tumor, CI in personal or family history of medullary thyroid cancer" → "Key Side Effects: nausea, vomiting, diarrhea, constipation, pancreatitis US Boxed Warning: may increase risk of thyroid c-cell tumor, CI in personal or family history of medullary thyroid cancer and in patients with multiple endocrine neoplasia syndrome type 2"
- insulin lispro (SQ) — brand: "Humalog" → "Humalog, Admelog, Lyumjev"
- dulaglutide (SQ) — essential: "Key Side Effects: nausea, vomiting, diarrhea, pancreatitis US Boxed Warning: may increase risk of thyroid c-cell tumor" → "Key Side Effects: nausea, vomiting, diarrhea, pancreatitis US Boxed Warning: may increase risk of thyroid c-cell tumor, CI in personal or family history of medullary thyroid cancer and in patients with multiple endocrine neoplasia syndrome type 2"
- tirzepatide (SQ) — essential: "Key Side Effects: nausea, vomiting, diarrhea, constipation, increased heart rate, pancreatitis US Boxed Warning: may increase risk of thyroid c-cell tumor" → "Key Side Effects: nausea, vomiting, diarrhea, constipation, increased heart rate, pancreatitis US Boxed Warning: may increase risk of thyroid c-cell tumor, CI in personal or family history of medullary thyroid cancer and in patients with multiple endocrine neoplasia syndrome type 2"
- insulin aspart (SQ) — brand: "Novolog" → "Novolog, Fiasp"
- semaglutide (PO, SQ) — brand: "SQ: Ozempic, Wegovy PO: Rybelsus" → "SQ: Ozempic, Wegovy PO: Rybelsus, Wegovy"
- semaglutide (PO, SQ) — essential: "Key Side Effects: nausea, vomiting, diarrhea, constipation, pancreatitis US Boxed Warning: may increase risk of thyroid c-cell tumor, CI in personal or family history of medullary thyroid cancer" → "Key Side Effects: nausea, vomiting, diarrhea, constipation, pancreatitis US Boxed Warning: may increase risk of thyroid c-cell tumor, CI in personal or family history of medullary thyroid cancer and in patients with multiple endocrine neoplasia syndrome type 2"

### p16 ENDOCRINE 2

- estradiol (transdermal, PO) — brand: "Transdermal: Climera, Vivelle Dot PO: Estrace" → "Transdermal: Climara, Vivelle Dot PO: Estrace"

### p17 ENDOCRINE 3

- phentermine (PO) — classification: "" → "CS-IV"
- phentermine (PO) — indication: "Obesity" → "Short term weight management"
- phentermine (PO) — essential: "Key Side Effects: tachycardia, hypertension, nausea, dizziness, xerostomia, agitation Other Notes: only approved for short-term use; CI in those with a history of cardiovascular disease or drug abuse, pregnancy, hyperthyroidism, or within 14 days of MAOI therapy" → "Key Side Effects: tachycardia, hypertension, nausea, dizziness, xerostomia, agitation Other Notes: only approved for short-term use up to 12 weeks; CI in those with a history of cardiovascular disease or drug abuse, pregnancy, hyperthyroidism, or within 14 days of MAOI therapy"

### p19 CENTRAL NERVOUS SYSTEM 2

- donepezil (PO) — generic: "donepezil (PO, transdermal)" → "donepezil (PO)"
- donepezil (PO) — brand: "PO: Aricept, Transdermal: Adlarity" → "PO: Aricept,"

### p23 GASTROENTEROLOGY 1

- linaclotide (PO) — essential: "Key Side Effects: diarrhea, abdominal pain US Boxed Warnings: do not use in patients <2 years of age (risk of death due to dehydration) Other Notes: mechanical gastrointestinal obstruction" → "Key Side Effects: diarrhea, abdominal pain US Boxed Warnings: do not use in patients <2 years of age (risk of death due to dehydration) Other Notes: contraindicated in mechanical gastrointestinal obstruction"

### p24 GASTROENTEROLOGY 2

- ondansetron (PO, IV) — brand: "Zofran" → "Zofran, Zofran ODT, Zuplenz"

### p27 PAIN, HEMATOLOGY, AND ONCOLOGY 3

- added: pembrolizumab (IV), pembrolizumab/berahyaluronidase alfa-pmph (SC)
- removed: pembrolizumab (IV)
- doxorubicin (IV) — essential: "Key Side Effects: cardiomyopathy, alopecia, nausea, vomiting, bone marrow suppression US Boxed Warnings: may cause cardiomyopathy, myelosuppression, secondary malignancies; extravasation can result in severe local tissue injury and necrosis Other Notes: may cause red discoloration of urine, tears, sweat, and saliva" → "Key Side Effects: cardiomyopathy, alopecia, nausea, vomiting, bone marrow suppression; US Boxed Warnings: may cause cardiomyopathy, myelosuppression, secondary malignancies; extravasation can result in severe local tissue injury and necrosis Other Notes: may cause red discoloration of urine, tears, sweat, and saliva"
- methotrexate (PO, IV, IT) — essential: "Key Side Effects: stomatitis, diarrhea, nausea, vomiting, thrombocytopenia, leukopenia, increased hepatic transaminases, pulmonary fibrosis (rare) US Boxed Warnings: serious toxic reactions (only use in life-threatening neoplastic disease, severe psoriasis, or severe rheumatoid arthritis); may cause fetal death and/or congenital abnormalities (avoid in pregnancy); severe (sometimes fatal) bone marrow suppression, aplastic anemia, and toxicity have been reported with concomitant administration of methotrexate and NSAIDs; may cause hepatotoxicity; methotrexate-induced lung disease, including acute or chronic interstitial pneumonitis may occur; severe (sometimes fatal) gastrointestinal toxicity has been reported with concomitant administration with NSAIDs Other Notes: folic acid supplementation may be taken during use to reduce hematologic, gastrointestinal, and hepatic side effects" → "Key Side Effects: stomatitis, diarrhea, nausea, vomiting, thrombocytopenia, leukopenia, increased hepatic transaminases, pulmonary fibrosis (rare) US Boxed Warnings: serious toxic reactions (only use in life-threatening neoplastic disease, severe psoriasis, or severe rheumatoid arthritis); may cause fetal death or congenital abnormalities (avoid in pregnancy); severe (sometimes fatal) bone marrow suppression, aplastic anemia, and toxicity have been reported with concomitant administration of methotrexate and NSAIDs; may cause hepatotoxicity; methotrexate-induced lung disease, including acute or chronic interstitial pneumonitis; severe (sometimes fatal) GI toxicity has been reported with concomitant administration with NSAIDs; hypersensitivity; for IT and high-dose therapy, use preservative-free formulation (may cause CNS toxicity or metabolic acidosis) Other Notes: folic acid supplementation may be taken during use to reduce hematologic, gastrointestinal, and hepatic side effects"
- cisplatin (IV, IT, IP) — essential: "Key Side Effects: bone marrow suppression, nausea, vomiting, nephrotoxicity, neurotoxicity, ototoxicity US Boxed Warnings: may cause severe myelosuppression, nausea and vomiting, renal toxicity, and dose-related neuropathy" → "Key Side Effects: bone marrow suppression, nausea/vomiting, nephrotoxicity, neurotoxicity, ototoxicity US Boxed Warnings: may cause severe myelosuppression, severe nausea/vomiting (requires highly effective antiemetic premedication), renal toxicity, and dose-related neuropathy"

